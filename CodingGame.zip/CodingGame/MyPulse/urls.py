from django.conf.urls import url
from MyPulse.views import *

urlpatterns = [
    url(r'', home),
    url(r'mail/', mail),
    url(r'apply_form/', apply_form),
]
